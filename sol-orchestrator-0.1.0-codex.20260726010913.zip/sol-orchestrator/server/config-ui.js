const session = new URLSearchParams(window.location.search).get("session") || "";
const apiUrl = (path) => `${path}?session=${encodeURIComponent(session)}`;

const elements = {
  form: document.querySelector("#config-form"),
  workspace: document.querySelector("#workspace"),
  status: document.querySelector("#connection-status"),
  message: document.querySelector("#message"),
  save: document.querySelector("#save"),
  profileList: document.querySelector("#profile-list"),
  endpointList: document.querySelector("#endpoint-list"),
  profileTemplate: document.querySelector("#profile-template"),
  endpointTemplate: document.querySelector("#endpoint-template"),
  solModel: document.querySelector("#sol-model"),
  reviewModel: document.querySelector("#review-model"),
  workerModels: document.querySelector("#worker-models"),
  mode: document.querySelector("#mode"),
  executionBackend: document.querySelector("#execution-backend"),
  artifactMode: document.querySelector("#artifact-mode"),
  taskAuto: document.querySelector("#task-auto"),
  tasksPerBatch: document.querySelector("#tasks-per-batch"),
  maxTasks: document.querySelector("#max-tasks"),
  maxParallel: document.querySelector("#max-parallel"),
  requestTimeout: document.querySelector("#request-timeout"),
  maxRetries: document.querySelector("#max-retries"),
  retryBase: document.querySelector("#retry-base")
};

let profiles = [];
let assignments = { solModel: "", reviewModel: "", workerModels: [] };

function setConnection(state, text) {
  elements.status.dataset.state = state;
  elements.status.textContent = text;
}

function setMessage(text, kind = "") {
  elements.message.textContent = text;
  elements.message.className = kind;
}

function profileNames() {
  return profiles.map((profile) => profile.name).filter(Boolean);
}

function normalizeAssignments() {
  const names = profileNames();
  if (!names.includes(assignments.solModel)) assignments.solModel = names[0] || "";
  if (!names.includes(assignments.reviewModel)) assignments.reviewModel = assignments.solModel;
  assignments.workerModels = assignments.workerModels.filter((name) => names.includes(name));
  if (!assignments.workerModels.length && names.length) assignments.workerModels = [names.find((name) => name !== assignments.solModel) || names[0]];
}

function renderAssignments() {
  normalizeAssignments();
  const names = profileNames();
  for (const [select, selected] of [[elements.solModel, assignments.solModel], [elements.reviewModel, assignments.reviewModel]]) {
    select.replaceChildren(...names.map((name) => new Option(name, name, false, name === selected)));
  }
  elements.workerModels.replaceChildren(...names.map((name) => {
    const label = document.createElement("label");
    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = name;
    input.checked = assignments.workerModels.includes(name);
    input.addEventListener("change", () => {
      assignments.workerModels = [...elements.workerModels.querySelectorAll("input:checked")].map((item) => item.value);
    });
    const text = document.createElement("span");
    text.textContent = name;
    label.append(input, text);
    return label;
  }));
}

function renderProfiles() {
  elements.profileList.replaceChildren();
  profiles.forEach((profile, index) => {
    const row = elements.profileTemplate.content.firstElementChild.cloneNode(true);
    for (const input of row.querySelectorAll("[data-field]")) {
      const field = input.dataset.field;
      input.value = profile[field] ?? "";
      input.addEventListener(field === "name" ? "change" : "input", () => {
        if (field === "name") {
          const oldName = profile.name;
          profile.name = input.value.trim();
          if (assignments.solModel === oldName) assignments.solModel = profile.name;
          if (assignments.reviewModel === oldName) assignments.reviewModel = profile.name;
          assignments.workerModels = assignments.workerModels.map((name) => name === oldName ? profile.name : name);
          renderAssignments();
          renderEndpoints();
        } else {
          profile[field] = input.value;
          if (field === "model") renderEndpoints();
        }
      });
    }
    row.querySelector(".remove-profile").addEventListener("click", () => {
      if (profiles.length === 1) {
        setMessage("至少保留一个模型配置。", "error");
        return;
      }
      profiles.splice(index, 1);
      renderProfiles();
      renderAssignments();
      renderEndpoints();
    });
    elements.profileList.append(row);
  });
}

function renderEndpoints() {
  elements.endpointList.replaceChildren();
  profiles.forEach((profile) => {
    const row = elements.endpointTemplate.content.firstElementChild.cloneNode(true);
    row.querySelector('[data-label="name"]').textContent = profile.name || "未命名模型";
    row.querySelector('[data-label="model"]').textContent = profile.model || "未设置模型 ID";
    for (const input of row.querySelectorAll("[data-field]")) {
      const field = input.dataset.field;
      if (input.type === "checkbox") input.checked = Boolean(profile[field]);
      else input.value = profile[field] ?? "";
      input.addEventListener("input", () => {
        profile[field] = input.type === "checkbox" ? input.checked : input.value;
      });
    }
    elements.endpointList.append(row);
  });
}

function applyConfig(workspace, config) {
  elements.workspace.textContent = workspace;
  profiles = Object.entries(config.models).map(([name, profile]) => ({
    name,
    model: profile.model || "",
    baseUrl: profile.baseUrl || "",
    apiKeyEnv: profile.apiKeyEnv || "",
    reasoningEffort: profile.reasoningEffort || "default",
    reasoningField: profile.reasoningField ?? "reasoning_effort",
    maxTokensField: profile.maxTokensField ?? "max_tokens",
    temperatureEnabled: Boolean(profile.temperatureEnabled)
  }));
  assignments = {
    solModel: config.solModel,
    reviewModel: config.reviewModel,
    workerModels: [...config.workerModels]
  };
  elements.mode.value = config.mode;
  elements.executionBackend.value = config.executionBackend;
  elements.artifactMode.value = config.artifactMode;
  const tokenInput = document.querySelector(`input[name="token-mode"][value="${config.tokenMode}"]`);
  if (tokenInput) tokenInput.checked = true;
  elements.taskAuto.checked = config.tasksPerBatch === 0;
  elements.tasksPerBatch.value = config.tasksPerBatch || Math.min(2, config.maxTasksPerRun);
  elements.tasksPerBatch.disabled = elements.taskAuto.checked;
  elements.maxTasks.value = config.maxTasksPerRun;
  elements.maxParallel.value = config.maxParallel;
  elements.requestTimeout.value = config.requestTimeoutMs;
  elements.maxRetries.value = config.maxRetries;
  elements.retryBase.value = config.retryBaseMs;
  renderProfiles();
  renderAssignments();
  renderEndpoints();
}

function numberValue(input) {
  return Number.parseInt(input.value, 10);
}

function buildPayload() {
  const names = profileNames();
  if (names.length !== profiles.length) throw new Error("模型配置名称不能为空。");
  if (new Set(names).size !== names.length) throw new Error("模型配置名称不能重复。");
  if (profiles.some((profile) => !profile.model.trim())) throw new Error("模型 ID 不能为空。");
  assignments.solModel = elements.solModel.value;
  assignments.reviewModel = elements.reviewModel.value;
  assignments.workerModels = [...elements.workerModels.querySelectorAll("input:checked")].map((item) => item.value);
  if (!assignments.workerModels.length) throw new Error("至少选择一个工作模型。");
  const tokenMode = document.querySelector('input[name="token-mode"]:checked')?.value;
  if (!tokenMode) throw new Error("请选择 Token 模式。");
  return {
    mode: elements.mode.value,
    executionBackend: elements.executionBackend.value,
    artifactMode: elements.artifactMode.value,
    tokenMode,
    tasksPerBatch: elements.taskAuto.checked ? 0 : numberValue(elements.tasksPerBatch),
    maxTasksPerRun: numberValue(elements.maxTasks),
    maxParallel: numberValue(elements.maxParallel),
    requestTimeoutMs: numberValue(elements.requestTimeout),
    maxRetries: numberValue(elements.maxRetries),
    retryBaseMs: numberValue(elements.retryBase),
    solModel: assignments.solModel,
    reviewModel: assignments.reviewModel,
    workerModels: assignments.workerModels,
    profiles: profiles.map(({ name, model, baseUrl, apiKeyEnv, reasoningEffort, reasoningField, maxTokensField, temperatureEnabled }) => ({
      name: name.trim(),
      model: model.trim(),
      baseUrl: baseUrl.trim(),
      apiKeyEnv: apiKeyEnv.trim(),
      reasoningEffort,
      reasoningField: reasoningField.trim(),
      maxTokensField: maxTokensField.trim(),
      temperatureEnabled
    }))
  };
}

async function load() {
  try {
    const response = await fetch(apiUrl("/api/config"), { cache: "no-store" });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "加载配置失败");
    applyConfig(payload.workspace, payload.config);
    setConnection("ready", "已连接");
  } catch (error) {
    setConnection("error", "连接失败");
    setMessage(error.message, "error");
  }
}

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((item) => {
      const active = item === tab;
      item.classList.toggle("active", active);
      item.setAttribute("aria-selected", String(active));
    });
    document.querySelectorAll(".panel").forEach((panel) => {
      const active = panel.dataset.panel === tab.dataset.tab;
      panel.classList.toggle("active", active);
      panel.hidden = !active;
    });
    if (tab.dataset.tab === "endpoints") renderEndpoints();
  });
});

document.querySelector("#add-profile").addEventListener("click", () => {
  const used = new Set(profileNames());
  let index = profiles.length + 1;
  while (used.has(`model-${index}`)) index += 1;
  profiles.push({
    name: `model-${index}`,
    model: "new-model-id",
    baseUrl: "",
    apiKeyEnv: "",
    reasoningEffort: "medium",
    reasoningField: "reasoning_effort",
    maxTokensField: "max_tokens",
    temperatureEnabled: false
  });
  renderProfiles();
  renderAssignments();
  renderEndpoints();
});

elements.solModel.addEventListener("change", () => { assignments.solModel = elements.solModel.value; });
elements.reviewModel.addEventListener("change", () => { assignments.reviewModel = elements.reviewModel.value; });
elements.taskAuto.addEventListener("change", () => {
  elements.tasksPerBatch.disabled = elements.taskAuto.checked;
});

elements.form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!elements.form.reportValidity()) return;
  elements.save.disabled = true;
  setMessage("正在保存…");
  try {
    const response = await fetch(apiUrl("/api/config"), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(buildPayload())
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "保存配置失败");
    applyConfig(payload.workspace, payload.config);
    setMessage("配置已保存。", "success");
  } catch (error) {
    setMessage(error.message, "error");
  } finally {
    elements.save.disabled = false;
  }
});

void load();
