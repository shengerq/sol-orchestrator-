#!/usr/bin/env node

import { createHash, randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import { promises as fs } from "node:fs";
import { createServer } from "node:http";
import path from "node:path";

const SERVER = { name: "sol-orchestrator", version: "0.2.0" };
const REASONING_EFFORTS = ["default", "none", "minimal", "low", "medium", "high", "xhigh"];
const TOKEN_MODES = ["economy", "balanced", "quality"];
const EXECUTION_BACKENDS = ["auto", "api-parallel", "host-agents"];
const TOKEN_POLICIES = {
  economy: { planning: 1400, worker: 1200, review: 420, final: 500, goalChars: 6000, contextChars: 6000, planChars: 1800, taskChars: 4000, dependencyChars: 3000, reviewResultChars: 7000, finalReviewChars: 1800 },
  balanced: { planning: 2400, worker: 2400, review: 700, final: 900, goalChars: 12000, contextChars: 12000, planChars: 3500, taskChars: 8000, dependencyChars: 6000, reviewResultChars: 14000, finalReviewChars: 3200 },
  quality: { planning: 4200, worker: 5000, review: 1200, final: 1800, goalChars: 24000, contextChars: 24000, planChars: 7000, taskChars: 16000, dependencyChars: 12000, reviewResultChars: 24000, finalReviewChars: 6000 }
};
const DEFAULTS = {
  mode: "auto",
  tokenMode: "economy",
  artifactMode: "compact",
  artifactDirectory: "sol-orchestrator-projects",
  executionBackend: "auto",
  tasksPerBatch: 0,
  maxTasksPerRun: 8,
  maxParallel: 2,
  requestTimeoutMs: 180000,
  maxRetries: 2,
  retryBaseMs: 750,
  solModel: "sol-5.6",
  reviewModel: "sol-5.6",
  workerModels: ["terra-5.6", "luna-5.6"],
  models: {
    "sol-5.6": { model: "5.6sol", baseUrl: "", apiKeyEnv: "SOL_API_KEY", reasoningEffort: "high", reasoningField: "reasoning_effort", maxTokensField: "max_tokens", temperatureEnabled: false },
    "terra-5.6": { model: "5.6terra", baseUrl: "", apiKeyEnv: "TERRA_API_KEY", reasoningEffort: "medium", reasoningField: "reasoning_effort", maxTokensField: "max_tokens", temperatureEnabled: false },
    "luna-5.6": { model: "5.6luna", baseUrl: "", apiKeyEnv: "LUNA_API_KEY", reasoningEffort: "medium", reasoningField: "reasoning_effort", maxTokensField: "max_tokens", temperatureEnabled: false }
  }
};

const TOOLS = [
  {
    name: "open_config_window",
    description: "Open a local Chinese configuration window for models, reasoning effort, task count, token mode, and automatic execution.",
    inputSchema: {
      type: "object",
      properties: {
        workspace: { type: "string", description: "Project root. Defaults to the current workspace." },
        launchBrowser: { type: "boolean", description: "Open the system browser automatically. Defaults to true." }
      }
    }
  },
  {
    name: "get_config",
    description: "Read the workspace orchestration configuration without exposing API key values.",
    inputSchema: workspaceSchema()
  },
  {
    name: "configure",
    description: "Configure automatic/manual mode, task count, and deployed OpenAI-compatible model profiles.",
    inputSchema: {
      type: "object",
      properties: {
        workspace: { type: "string", description: "Project root. Defaults to the current workspace." },
        mode: { type: "string", enum: ["auto", "manual", "documents"] },
        tokenMode: { type: "string", enum: TOKEN_MODES, description: "economy is the default; quality restores larger context and output limits." },
        artifactMode: { type: "string", enum: ["compact", "expanded"], description: "compact keeps two files after review; expanded keeps every handoff file." },
        artifactDirectory: { type: "string", description: "Workspace-relative folder for project documents and run bundles." },
        executionBackend: { type: "string", enum: EXECUTION_BACKENDS, description: "auto uses API parallelism unless the host skill explicitly selects host-agents." },
        tasksPerBatch: { type: "integer", minimum: 0, maximum: 64, description: "0 lets Sol choose automatically; otherwise use 1..N." },
        maxTasksPerRun: { type: "integer", minimum: 1, maximum: 64 },
        maxParallel: { type: "integer", minimum: 1, maximum: 16 },
        requestTimeoutMs: { type: "integer", minimum: 1000, maximum: 1800000 },
        maxRetries: { type: "integer", minimum: 0, maximum: 8 },
        retryBaseMs: { type: "integer", minimum: 100, maximum: 30000 },
        solModel: { type: "string" },
        reviewModel: { type: "string" },
        workerModels: { type: "array", minItems: 1, items: { type: "string" } },
        replaceProfiles: { type: "boolean", description: "Replace the complete model profile list instead of merging it. Used by the configuration window." },
        profiles: {
          type: "array",
          items: {
            type: "object",
            required: ["name"],
            properties: {
              name: { type: "string" },
              model: { type: "string" },
              baseUrl: { type: "string" },
              apiKeyEnv: { type: "string" },
              reasoningEffort: { type: "string", enum: REASONING_EFFORTS },
              reasoningField: { type: "string", description: "Request body field, normally reasoning_effort. Empty disables it." },
              maxTokensField: { type: "string", description: "Usually max_tokens or max_completion_tokens. Empty disables output caps." },
              temperatureEnabled: { type: "boolean", description: "Send temperature only when the endpoint supports it." }
            }
          }
        }
      }
    }
  },
  {
    name: "plan_workflow",
    description: "Ask Sol to plan one to N tasks and write detailed local prompt documents without executing workers.",
    inputSchema: runSchema(false)
  },
  {
    name: "run_workflow",
    description: "Run planning, dependency-aware Sol/Terra/Luna execution, one retry, and mandatory Sol review.",
    inputSchema: runSchema(true)
  },
  {
    name: "execute_run",
    description: "Execute a previously displayed plan, then return a final project review card for chat.",
    inputSchema: {
      type: "object",
      required: ["runDirectory"],
      properties: {
        runDirectory: { type: "string" },
        workerModel: { type: "string" },
        reasoningEffort: { type: "string", enum: REASONING_EFFORTS },
        reasoningByModel: { type: "object", additionalProperties: { type: "string", enum: REASONING_EFFORTS } },
        tokenMode: { type: "string", enum: TOKEN_MODES },
        executionBackend: { type: "string", enum: EXECUTION_BACKENDS }
      }
    }
  },
  {
    name: "resume_run",
    description: "Resume failed, interrupted, or host-agent runs from task checkpoints without repeating approved tasks.",
    inputSchema: {
      type: "object",
      required: ["runDirectory"],
      properties: {
        runDirectory: { type: "string" },
        workerModel: { type: "string" },
        reasoningEffort: { type: "string", enum: REASONING_EFFORTS },
        reasoningByModel: { type: "object", additionalProperties: { type: "string", enum: REASONING_EFFORTS } },
        tokenMode: { type: "string", enum: TOKEN_MODES },
        executionBackend: { type: "string", enum: EXECUTION_BACKENDS }
      }
    }
  },
  {
    name: "continue_goal",
    description: "For a long-running /gaol project, decide completion from compact Sol reviews or create the next task batch under the same project ID.",
    inputSchema: {
      type: "object",
      required: ["runDirectory"],
      properties: {
        runDirectory: { type: "string" },
        taskCount: { type: "integer", minimum: 1, maximum: 64 },
        workerModel: { type: "string" },
        tokenMode: { type: "string", enum: TOKEN_MODES },
        executionBackend: { type: "string", enum: EXECUTION_BACKENDS },
        reasoningEffort: { type: "string", enum: REASONING_EFFORTS },
        reasoningByModel: { type: "object", additionalProperties: { type: "string", enum: REASONING_EFFORTS } }
      }
    }
  },
  {
    name: "review_run",
    description: "Review existing local result documents with Sol and write per-task plus final review documents.",
    inputSchema: {
      type: "object",
      required: ["runDirectory"],
      properties: {
        runDirectory: { type: "string" },
        reasoningEffort: { type: "string", enum: REASONING_EFFORTS },
        reasoningByModel: { type: "object", additionalProperties: { type: "string", enum: REASONING_EFFORTS } },
        tokenMode: { type: "string", enum: TOKEN_MODES }
      }
    }
  },
  {
    name: "run_status",
    description: "Read a run state document and list missing result files.",
    inputSchema: {
      type: "object",
      required: ["runDirectory"],
      properties: { runDirectory: { type: "string" } }
    }
  }
];

function workspaceSchema() {
  return {
    type: "object",
    properties: { workspace: { type: "string", description: "Project root. Defaults to the current workspace." } }
  };
}

function runSchema(withExecution) {
  return {
    type: "object",
    required: ["goal"],
    properties: {
      goal: { type: "string", description: "The complete project goal and constraints." },
      projectName: { type: "string", description: "Short project name shown in chat review cards." },
      longRunning: { type: "boolean", description: "Keep the /gaol active and request another batch until Sol proves the final goal complete." },
      workspace: { type: "string" },
      taskCount: { type: "integer", minimum: 1, maximum: 64 },
      workerModel: { type: "string", description: "Manual worker selection; omit in auto mode." },
      reasoningEffort: { type: "string", enum: REASONING_EFFORTS, description: "Temporary effort override for every model in this run." },
      reasoningByModel: { type: "object", additionalProperties: { type: "string", enum: REASONING_EFFORTS }, description: "Per-profile effort overrides, for example sol-5.6: high." },
      tokenMode: { type: "string", enum: TOKEN_MODES, description: "Temporary token policy override." },
      executionBackend: { type: "string", enum: EXECUTION_BACKENDS, description: "host-agents prepares subagent task packets; api-parallel calls deployed model endpoints." },
      context: { type: "string", description: "Optional concise project context." },
      execute: withExecution ? { type: "boolean", const: true } : { type: "boolean", const: false }
    }
  };
}

function workspaceRoot(raw) {
  return path.resolve(raw || process.env.SOL_ORCHESTRATOR_WORKSPACE || process.env.CODEX_WORKSPACE_ROOT || process.cwd());
}

function controlRoot(workspace) {
  return path.join(workspace, ".sol-orchestrator");
}

function artifactRoot(workspace, config) {
  return path.resolve(workspace, config.artifactDirectory);
}

function projectArtifactRoot(workspace, config, projectId) {
  return path.join(artifactRoot(workspace, config), projectId);
}

async function writeProjectDocument(state, plan, dir, config) {
  const projectRoot = state.projectRoot || projectArtifactRoot(state.workspace, config, state.projectId);
  const file = path.join(projectRoot, "PROJECT.md");
  const tasks = plan.tasks.length
    ? plan.tasks.map((task) => `- ${task.id}｜${task.title}｜${state.tasks?.[task.id]?.model || task.assignedModel || "pending"}｜${state.tasks?.[task.id]?.status || "planned"}`).join("\n")
    : "- No pending tasks.";
  const continuation = state.goalComplete
    ? "The final goal is complete. Review the completion evidence before reopening it."
    : `Use $sol-orchestrator to continue /gaol ${state.goal}. Read run ${dir}; if needsContinuation is true, call continue_goal, display its project card, then call execute_run.`;
  await writeText(file, [
    `# ${state.projectId}: ${state.projectName}`,
    "",
    `/gaol ${state.goal}`,
    "",
    `- Status: ${state.status}`,
    `- Current batch: B${String(state.batchNumber || 1).padStart(2, "0")}`,
    `- Run directory: ${dir}`,
    `- Token mode: ${state.tokenMode || config.tokenMode}`,
    `- Artifact mode: ${state.artifactMode || config.artifactMode}`,
    "",
    "## Current tasks",
    "",
    tasks,
    "",
    "## Continue prompt",
    "",
    continuation
  ].join("\n"));
  state.projectRoot = projectRoot;
  state.projectDocument = file;
  return file;
}

async function readJson(file) {
  return JSON.parse(await fs.readFile(file, "utf8"));
}

async function writeJson(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

async function writeText(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, value.endsWith("\n") ? value : `${value}\n`, "utf8");
}

function deepMerge(base, extra) {
  const result = structuredClone(base);
  for (const [key, value] of Object.entries(extra || {})) {
    if (value && typeof value === "object" && !Array.isArray(value) && result[key] && typeof result[key] === "object") {
      result[key] = deepMerge(result[key], value);
    } else {
      result[key] = value;
    }
  }
  return result;
}

async function loadConfig(workspace) {
  const file = path.join(controlRoot(workspace), "config.json");
  try {
    const saved = await readJson(file);
    const merged = deepMerge(DEFAULTS, saved);
    if (saved._replaceDefaultProfiles) merged.models = structuredClone(saved.models || {});
    for (const [name, profile] of Object.entries(merged.models || {})) {
      merged.models[name] = {
        apiKeyEnv: "",
        reasoningEffort: "default",
        reasoningField: "reasoning_effort",
        maxTokensField: "max_tokens",
        temperatureEnabled: false,
        ...profile
      };
    }
    return validateConfig(merged);
  } catch (error) {
    if (error.code === "ENOENT") return structuredClone(DEFAULTS);
    throw error;
  }
}

function validateConfig(config) {
  if (!["auto", "manual", "documents"].includes(config.mode)) throw new Error("mode must be auto, manual, or documents");
  if (!TOKEN_MODES.includes(config.tokenMode)) throw new Error("tokenMode must be economy, balanced, or quality");
  if (!["compact", "expanded"].includes(config.artifactMode)) throw new Error("artifactMode must be compact or expanded");
  if (!EXECUTION_BACKENDS.includes(config.executionBackend)) throw new Error("executionBackend must be auto, api-parallel, or host-agents");
  if (!config.artifactDirectory || path.isAbsolute(config.artifactDirectory) || config.artifactDirectory.split(/[\\/]+/).some((part) => part === "..")) throw new Error("artifactDirectory must be a safe workspace-relative path");
  for (const key of ["tasksPerBatch", "maxTasksPerRun", "maxParallel", "requestTimeoutMs"]) {
    if (!Number.isInteger(config[key])) throw new Error(`${key} must be an integer`);
  }
  if (config.tasksPerBatch < 0 || config.tasksPerBatch > config.maxTasksPerRun) throw new Error("tasksPerBatch must be 0 or between 1 and maxTasksPerRun");
  if (config.maxTasksPerRun < 1 || config.maxTasksPerRun > 64) throw new Error("maxTasksPerRun must be between 1 and 64");
  if (config.maxParallel < 1 || config.maxParallel > 16) throw new Error("maxParallel must be between 1 and 16");
  if (!Number.isInteger(config.maxRetries) || config.maxRetries < 0 || config.maxRetries > 8) throw new Error("maxRetries must be between 0 and 8");
  if (!Number.isInteger(config.retryBaseMs) || config.retryBaseMs < 100 || config.retryBaseMs > 30000) throw new Error("retryBaseMs must be between 100 and 30000");
  for (const name of [config.solModel, config.reviewModel, ...config.workerModels]) {
    if (!config.models[name]) throw new Error(`Unknown model profile: ${name}`);
  }
  for (const [name, profile] of Object.entries(config.models)) {
    if (!profile.model || typeof profile.model !== "string") throw new Error(`Model profile '${name}' requires model`);
    if (typeof profile.baseUrl !== "string") throw new Error(`Model profile '${name}' requires baseUrl`);
    if (!REASONING_EFFORTS.includes(profile.reasoningEffort)) throw new Error(`Invalid reasoningEffort for '${name}'`);
    if (typeof profile.reasoningField !== "string") throw new Error(`reasoningField for '${name}' must be a string`);
    if (typeof profile.maxTokensField !== "string") throw new Error(`maxTokensField for '${name}' must be a string`);
    if (typeof profile.temperatureEnabled !== "boolean") throw new Error(`temperatureEnabled for '${name}' must be a boolean`);
  }
  return config;
}

async function configure(args) {
  const workspace = workspaceRoot(args.workspace);
  const current = await loadConfig(workspace);
  const next = structuredClone(current);
  for (const key of ["mode", "tokenMode", "artifactMode", "artifactDirectory", "executionBackend", "tasksPerBatch", "maxTasksPerRun", "maxParallel", "requestTimeoutMs", "maxRetries", "retryBaseMs", "solModel", "reviewModel", "workerModels"]) {
    if (args[key] !== undefined) next[key] = args[key];
  }
  if (args.replaceProfiles) {
    next.models = {};
    next._replaceDefaultProfiles = true;
  }
  for (const profile of args.profiles || []) {
    if (!profile.name || typeof profile.name !== "string") throw new Error("Every model profile requires a non-empty name");
    const existing = next.models[profile.name] || {
      model: "",
      baseUrl: "",
      apiKeyEnv: "",
      reasoningEffort: "default",
      reasoningField: "reasoning_effort",
      maxTokensField: "max_tokens",
      temperatureEnabled: false
    };
    next.models[profile.name] = {
      ...existing,
      ...(profile.model !== undefined ? { model: profile.model } : {}),
      ...(profile.baseUrl !== undefined ? { baseUrl: profile.baseUrl } : {}),
      ...(profile.apiKeyEnv !== undefined ? { apiKeyEnv: profile.apiKeyEnv } : {}),
      ...(profile.reasoningEffort !== undefined ? { reasoningEffort: profile.reasoningEffort } : {}),
      ...(profile.reasoningField !== undefined ? { reasoningField: profile.reasoningField } : {}),
      ...(profile.maxTokensField !== undefined ? { maxTokensField: profile.maxTokensField } : {}),
      ...(profile.temperatureEnabled !== undefined ? { temperatureEnabled: profile.temperatureEnabled } : {})
    };
  }
  validateConfig(next);
  const file = path.join(controlRoot(workspace), "config.json");
  await writeJson(file, next);
  return { configured: true, configPath: file, config: redactConfig(next) };
}

function redactConfig(config) {
  const { _replaceDefaultProfiles, ...publicConfig } = config;
  return {
    ...publicConfig,
    models: Object.fromEntries(Object.entries(config.models).map(([name, profile]) => [name, {
      ...profile,
      apiKeyAvailable: Boolean(profile.apiKeyEnv && process.env[profile.apiKeyEnv])
    }]))
  };
}

let configUiServer;
const configUiSessions = new Map();
const CONFIG_UI_SESSION_MS = 30 * 60 * 1000;
const CONFIG_UI_MAX_BODY = 64 * 1024;

function sendHttpJson(response, status, value) {
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  });
  response.end(JSON.stringify(value));
}

function configUiSession(url) {
  const token = url.searchParams.get("session") || "";
  const session = configUiSessions.get(token);
  if (!session || session.expiresAt <= Date.now()) {
    if (token) configUiSessions.delete(token);
    return null;
  }
  session.expiresAt = Date.now() + CONFIG_UI_SESSION_MS;
  return session;
}

async function readHttpJson(request) {
  let body = "";
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body, "utf8") > CONFIG_UI_MAX_BODY) throw new Error("Request body is too large");
  }
  const value = JSON.parse(body || "{}");
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Request body must be an object");
  return value;
}

async function configUiAsset(name) {
  return fs.readFile(new URL(`./${name}`, import.meta.url));
}

async function handleConfigUiRequest(request, response) {
  const url = new URL(request.url || "/", "http://127.0.0.1");
  response.setHeader("content-security-policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  response.setHeader("referrer-policy", "no-referrer");
  if (request.method === "GET" && url.pathname === "/config-ui.css") {
    response.writeHead(200, { "content-type": "text/css; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
    response.end(await configUiAsset("config-ui.css"));
    return;
  }
  if (request.method === "GET" && url.pathname === "/config-ui.js") {
    response.writeHead(200, { "content-type": "text/javascript; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
    response.end(await configUiAsset("config-ui.js"));
    return;
  }
  const session = configUiSession(url);
  if (!session) {
    sendHttpJson(response, 403, { error: "配置会话已失效，请从 Codex 重新打开配置窗口。" });
    return;
  }
  if (request.method === "GET" && url.pathname === "/") {
    response.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
    response.end(await configUiAsset("config-ui.html"));
    return;
  }
  if (request.method === "GET" && url.pathname === "/api/config") {
    sendHttpJson(response, 200, { workspace: session.workspace, config: redactConfig(await loadConfig(session.workspace)) });
    return;
  }
  if (request.method === "POST" && url.pathname === "/api/config") {
    const body = await readHttpJson(request);
    delete body.workspace;
    const saved = await configure({ ...body, workspace: session.workspace, replaceProfiles: true });
    sendHttpJson(response, 200, { workspace: session.workspace, ...saved });
    return;
  }
  sendHttpJson(response, 404, { error: "Not found" });
}

async function ensureConfigUiServer() {
  if (configUiServer) return configUiServer;
  const server = createServer((request, response) => {
    void handleConfigUiRequest(request, response).catch((error) => sendHttpJson(response, 400, { error: error?.message || String(error) }));
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  configUiServer = server;
  return server;
}

function launchConfigBrowser(url) {
  try {
    const options = { detached: true, stdio: "ignore", windowsHide: true };
    const child = process.platform === "win32"
      ? spawn(process.env.ComSpec || "cmd.exe", ["/d", "/c", "start", "", url], options)
      : process.platform === "darwin"
        ? spawn("open", [url], options)
        : spawn("xdg-open", [url], options);
    child.unref();
    return true;
  } catch {
    return false;
  }
}

async function openConfigWindow(args = {}) {
  const workspace = workspaceRoot(args.workspace);
  await loadConfig(workspace);
  const server = await ensureConfigUiServer();
  const address = server.address();
  const token = randomBytes(24).toString("hex");
  const expiresAt = Date.now() + CONFIG_UI_SESSION_MS;
  configUiSessions.set(token, { workspace, expiresAt });
  for (const [key, session] of configUiSessions) if (session.expiresAt <= Date.now()) configUiSessions.delete(key);
  const url = `http://127.0.0.1:${address.port}/?session=${token}`;
  const opened = args.launchBrowser === false ? false : launchConfigBrowser(url);
  return {
    workspace,
    url,
    opened,
    expiresAt: new Date(expiresAt).toISOString(),
    chatDisplay: [
      "### Sol Orchestrator 模型配置",
      `- 项目：${workspace}`,
      `- [打开配置窗口](${url})`,
      `- 浏览器：${opened ? "已请求打开" : "请点击上方链接"}`,
      "- 会话：30 分钟内有效"
    ].join("\n")
  };
}

function endpoint(baseUrl) {
  const clean = baseUrl.replace(/\/+$/, "");
  if (!clean) return "";
  if (clean.endsWith("/chat/completions")) return clean;
  return `${clean}/chat/completions`;
}

function selectedReasoning(config, profileName, options = {}) {
  const effort = options.reasoningByModel?.[profileName] ?? options.reasoningEffort ?? config.models[profileName]?.reasoningEffort ?? "default";
  if (!REASONING_EFFORTS.includes(effort)) throw new Error(`Invalid reasoning effort '${effort}' for '${profileName}'`);
  return effort;
}

function selectedTokenMode(config, options = {}) {
  const mode = options.tokenMode || config.tokenMode || "economy";
  if (!TOKEN_MODES.includes(mode)) throw new Error(`Invalid token mode '${mode}'`);
  return mode;
}

function selectedExecutionBackend(config, options = {}) {
  const requested = options.executionBackend || config.executionBackend || "auto";
  if (!EXECUTION_BACKENDS.includes(requested)) throw new Error(`Invalid execution backend '${requested}'`);
  return requested === "auto" ? "api-parallel" : requested;
}

function tokenPolicy(config, options = {}) {
  return TOKEN_POLICIES[selectedTokenMode(config, options)];
}

function clipped(value, maxChars) {
  const text = String(value || "");
  if (text.length <= maxChars) return text;
  return `${text.slice(0, maxChars)}\n[truncated locally to save tokens]`;
}

function outputBudget(config, profile, options = {}) {
  const phase = options.phase === "planning" || options.phase === "review" || options.phase === "final" ? options.phase : "worker";
  return tokenPolicy(config, options)[phase];
}

const usageWrites = new Map();

async function recordUsage(file, entry) {
  if (!file) return;
  const previous = usageWrites.get(file) || Promise.resolve();
  const next = previous.then(async () => {
    let usage = { calls: [], totals: { promptTokens: 0, completionTokens: 0, totalTokens: 0 }, byPhase: {} };
    try { usage = await readJson(file); }
    catch (error) { if (error.code !== "ENOENT") throw error; }
    usage.calls.push(entry);
    usage.totals.promptTokens += entry.promptTokens;
    usage.totals.completionTokens += entry.completionTokens;
    usage.totals.totalTokens += entry.totalTokens;
    const phase = usage.byPhase[entry.phase] || { calls: 0, totalTokens: 0 };
    phase.calls += 1;
    phase.totalTokens += entry.totalTokens;
    usage.byPhase[entry.phase] = phase;
    await writeJson(file, usage);
  });
  usageWrites.set(file, next);
  try { await next; }
  finally { if (usageWrites.get(file) === next) usageWrites.delete(file); }
}

async function readUsage(dir) {
  try { return await readJson(path.join(dir, "usage.json")); }
  catch (error) {
    if (error.code === "ENOENT") return { calls: [], totals: { promptTokens: 0, completionTokens: 0, totalTokens: 0 }, byPhase: {} };
    throw error;
  }
}

async function readBundle(dir) {
  return readJson(path.join(dir, "run-bundle.json"));
}

async function readRunState(dir) {
  try { return await readJson(path.join(dir, "state.json")); }
  catch (error) {
    if (error.code !== "ENOENT") throw error;
    return (await readBundle(dir)).state;
  }
}

async function readRunPlan(dir) {
  try { return await readJson(path.join(dir, "plan.json")); }
  catch (error) {
    if (error.code !== "ENOENT") throw error;
    return (await readBundle(dir)).plan;
  }
}

async function readOptionalText(file) {
  try { return await fs.readFile(file, "utf8"); }
  catch (error) { if (error.code === "ENOENT") return ""; throw error; }
}

async function compactRun(dir, state, plan) {
  if (state.artifactMode !== "compact") return state;
  const resolvedDir = path.resolve(dir);
  const allowedRoot = path.resolve(state.projectRoot || path.join(controlRoot(state.workspace), "runs"));
  if (resolvedDir === allowedRoot || !resolvedDir.startsWith(`${allowedRoot}${path.sep}`)) throw new Error("Refusing to compact a directory outside the workspace run root");
  const prompts = {};
  const results = {};
  const reviews = {};
  for (const task of plan.tasks) {
    prompts[task.id] = await readOptionalText(path.join(dir, "tasks", `${task.id}.prompt.md`));
    results[task.id] = await readOptionalText(path.join(dir, "results", `${task.id}.result.md`));
    reviews[task.id] = await readOptionalText(path.join(dir, "reviews", `${task.id}.review.md`));
  }
  const bundleFile = path.join(dir, "run-bundle.json");
  state.bundlePath = bundleFile;
  const bundle = {
    schemaVersion: 1,
    archivedAt: new Date().toISOString(),
    state,
    plan,
    request: await readOptionalText(path.join(dir, "request.md")),
    prompts,
    results,
    reviews,
    finalReview: await readOptionalText(path.join(dir, "final-review.md")),
    usage: state.usage || await readUsage(dir)
  };
  await writeJson(bundleFile, bundle);
  for (const folder of ["tasks", "results", "reviews"]) await fs.rm(path.join(dir, folder), { recursive: true, force: true });
  for (const file of ["request.md", "plan.json", "plan.md", "state.json", "usage.json"]) await fs.rm(path.join(dir, file), { force: true });
  return state;
}

async function expandBundleForReview(dir, bundle) {
  await writeJson(path.join(dir, "state.json"), bundle.state);
  await writeJson(path.join(dir, "plan.json"), bundle.plan);
  await writeText(path.join(dir, "request.md"), bundle.request || "# Restored request");
  await writeText(path.join(dir, "plan.md"), planDocument(bundle.plan, bundle.state));
  await writeJson(path.join(dir, "usage.json"), bundle.usage || { calls: [], totals: { promptTokens: 0, completionTokens: 0, totalTokens: 0 }, byPhase: {} });
  for (const task of bundle.plan.tasks) {
    await writeText(path.join(dir, "tasks", `${task.id}.prompt.md`), bundle.prompts?.[task.id] || promptDocument(bundle.state.goal, bundle.plan, task));
    if (bundle.results?.[task.id]) await writeText(path.join(dir, "results", `${task.id}.result.md`), bundle.results[task.id]);
    if (bundle.reviews?.[task.id]) await writeText(path.join(dir, "reviews", `${task.id}.review.md`), bundle.reviews[task.id]);
  }
  if (bundle.finalReview) await writeText(path.join(dir, "final-review.md"), bundle.finalReview);
}

function estimateTokens(value) {
  let ascii = 0;
  let nonAscii = 0;
  for (const char of String(value || "")) {
    if (char.codePointAt(0) <= 0x7f) ascii += 1;
    else nonAscii += 1;
  }
  return Math.max(1, Math.ceil(ascii / 4 + nonAscii / 1.5));
}

async function callModel(config, profileName, messages, temperature = 0.2, options = {}) {
  const profile = config.models[profileName];
  if (!profile) throw new Error(`Unknown model profile: ${profileName}`);
  const url = endpoint(profile.baseUrl);
  if (!url) throw new Error(`Model profile '${profileName}' has no baseUrl. Run configure first.`);
  const headers = { "content-type": "application/json" };
  if (profile.apiKeyEnv) {
    const key = process.env[profile.apiKeyEnv];
    if (key) headers.authorization = `Bearer ${key}`;
  }
  const body = { model: profile.model, messages };
  if (profile.temperatureEnabled) body.temperature = temperature;
  const effort = selectedReasoning(config, profileName, options);
  if (effort !== "default" && profile.reasoningField) body[profile.reasoningField] = effort;
  if (profile.maxTokensField) body[profile.maxTokensField] = outputBudget(config, profile, options);
  for (let attempt = 0; attempt <= config.maxRetries; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), config.requestTimeoutMs);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers,
        signal: controller.signal,
        body: JSON.stringify(body)
      });
      const raw = await response.text();
      if (!response.ok) {
        const error = new Error(`${profileName} returned HTTP ${response.status}: ${raw.slice(0, 300)}`);
        error.retryable = [408, 409, 425, 429].includes(response.status) || response.status >= 500;
        error.retryAfterMs = Math.min(Number(response.headers.get("retry-after")) * 1000 || 0, 30000);
        throw error;
      }
      const payload = JSON.parse(raw);
      const content = payload.choices?.[0]?.message?.content ?? payload.output_text;
      if (typeof content !== "string" || !content.trim()) throw new Error(`${profileName} returned no text content`);
      const reported = payload.usage || {};
      const promptTokens = Number(reported.prompt_tokens ?? reported.input_tokens) || estimateTokens(JSON.stringify(messages));
      const completionTokens = Number(reported.completion_tokens ?? reported.output_tokens) || estimateTokens(content);
      await recordUsage(options.usageFile, {
        at: new Date().toISOString(),
        phase: options.phase || "worker",
        profile: profileName,
        model: profile.model,
        tokenMode: selectedTokenMode(config, options),
        attempts: attempt + 1,
        reported: Boolean(payload.usage),
        promptTokens,
        completionTokens,
        totalTokens: Number(reported.total_tokens) || promptTokens + completionTokens
      });
      return content.trim();
    } catch (error) {
      const retryable = error.retryable || error.name === "AbortError" || error instanceof TypeError;
      if (!retryable || attempt >= config.maxRetries) throw error;
      const delayMs = error.retryAfterMs || Math.min(config.retryBaseMs * (2 ** attempt), 30000);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error(`${profileName} request failed after retries`);
}

function extractJson(text) {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1];
  const candidate = fenced || text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
  if (!candidate) throw new Error("Model response did not contain JSON");
  return JSON.parse(candidate);
}

async function callJson(config, profileName, messages, options = {}) {
  return extractJson(await callModel(config, profileName, messages, 0.1, options));
}

function requestedCount(args, config) {
  const count = args.taskCount ?? config.tasksPerBatch;
  if (count === 0) return null;
  if (!Number.isInteger(count) || count < 1 || count > config.maxTasksPerRun) {
    throw new Error(`taskCount must be between 1 and ${config.maxTasksPerRun}`);
  }
  return count;
}

function planningMessages(goal, context, count, config, options = {}) {
  const policy = tokenPolicy(config, options);
  const countRule = count
    ? `Create exactly ${count} total tasks.`
    : `Choose 1 to ${config.maxTasksPerRun} total tasks according to complexity.`;
  return [
    {
      role: "system",
      content: [
        "You are Sol 5.6, the accountable lead.",
        countRule,
        "Prefer fewer tasks. Split only when parallelism or specialization clearly repays another model call.",
        "Assign the hardest, highest-risk, security-sensitive, or integrative task to owner 'sol'.",
        "Delegate only bounded work. Make prompts self-contained but concise; avoid repeating the goal.",
        "Return JSON only: {summary, tasks:[{id,title,owner,preferredModel,description,prompt,acceptanceCriteria,dependsOn,deliverable}] }.",
        "Use T01, T02, ...; arrays for criteria/dependencies; at least one sol task.",
        "Match the user's language. Do not include secrets."
      ].join("\n")
    },
    { role: "user", content: `Goal:\n${clipped(goal, policy.goalChars)}\n\nContext:\n${clipped(context || "None provided", policy.contextChars)}\n\nWorkers: ${config.workerModels.join(", ")}` }
  ];
}

function normalizePlan(raw, goal, count, config) {
  if (!raw || !Array.isArray(raw.tasks) || raw.tasks.length === 0) throw new Error("Sol returned an empty plan");
  let tasks = raw.tasks.slice(0, config.maxTasksPerRun).map((task, index) => ({
    id: `T${String(index + 1).padStart(2, "0")}`,
    title: String(task.title || `Task ${index + 1}`),
    owner: task.owner === "sol" ? "sol" : "worker",
    preferredModel: typeof task.preferredModel === "string" ? task.preferredModel : "",
    description: String(task.description || ""),
    prompt: String(task.prompt || task.description || ""),
    acceptanceCriteria: Array.isArray(task.acceptanceCriteria) ? task.acceptanceCriteria.map(String) : [],
    dependsOn: Array.isArray(task.dependsOn) ? task.dependsOn.map(String) : [],
    deliverable: String(task.deliverable || "A complete result document")
  }));
  if (count && tasks.length !== count) throw new Error(`Sol returned ${tasks.length} tasks; expected ${count}`);
  if (!tasks.some((task) => task.owner === "sol")) tasks[0].owner = "sol";
  const validIds = new Set(tasks.map((task) => task.id));
  tasks = tasks.map((task, index) => ({
    ...task,
    dependsOn: task.dependsOn
      .map((id) => /^T\d+$/i.test(id) ? `T${String(Number(id.slice(1))).padStart(2, "0")}` : id)
      .filter((id) => validIds.has(id) && id !== task.id),
    assignedModel: task.owner === "sol" ? config.solModel : ""
  }));
  return { summary: String(raw.summary || goal), tasks };
}

function topologicalTaskOrder(tasks) {
  const byId = new Map(tasks.map((task) => [task.id, task]));
  const indegree = new Map(tasks.map((task) => [task.id, 0]));
  const children = new Map(tasks.map((task) => [task.id, []]));
  for (const task of tasks) {
    for (const dependency of task.dependsOn) {
      if (!byId.has(dependency)) continue;
      indegree.set(task.id, indegree.get(task.id) + 1);
      children.get(dependency).push(task.id);
    }
  }
  const queue = tasks.filter((task) => indegree.get(task.id) === 0).map((task) => task.id);
  const ordered = [];
  while (queue.length) {
    const id = queue.shift();
    ordered.push(id);
    for (const child of children.get(id)) {
      indegree.set(child, indegree.get(child) - 1);
      if (indegree.get(child) === 0) queue.push(child);
    }
  }
  for (const task of tasks) if (!ordered.includes(task.id)) ordered.push(task.id);
  return ordered;
}

function runId(goal) {
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const hash = createHash("sha256").update(goal).digest("hex").slice(0, 6);
  return `${stamp}-${hash}-${randomBytes(2).toString("hex")}`;
}

let projectCounterWrite = Promise.resolve();

async function nextProjectId(workspace) {
  let projectId;
  projectCounterWrite = projectCounterWrite.then(async () => {
    const file = path.join(controlRoot(workspace), "counter.json");
    let current = 0;
    try { current = Number((await readJson(file)).lastProjectNumber) || 0; }
    catch (error) { if (error.code !== "ENOENT") throw error; }
    current += 1;
    await writeJson(file, { lastProjectNumber: current });
    projectId = `P${String(current).padStart(4, "0")}`;
  });
  await projectCounterWrite;
  return projectId;
}

function compactText(value, length = 180) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  return text.length > length ? `${text.slice(0, length - 3)}...` : text;
}

function projectName(args) {
  return compactText(args.projectName || args.goal.split(/\r?\n/)[0], 72) || "Untitled project";
}

function chatCard(dir, state, plan, config, stage) {
  const lines = [
    `/gaol ${compactText(state.goal, 320)}`,
    "",
    `### 项目 ${state.projectId} · ${state.projectName} · 批次 B${String(state.batchNumber || 1).padStart(2, "0")}`,
    `状态：${stage || state.status}｜任务：${plan.tasks.length}｜后端：${state.executionBackend || selectedExecutionBackend(config)}｜Token：${state.tokenMode || config.tokenMode}｜归档：${state.artifactMode || config.artifactMode}｜目录：${dir}`,
    ""
  ];
  for (const task of plan.tasks) {
    const taskState = state.tasks?.[task.id] || {};
    const modelName = taskState.model || task.assignedModel || "pending";
    const profile = config.models[modelName];
    const actualModel = taskState.modelId || profile?.model;
    const effort = taskState.reasoningEffort || task.assignedReasoning || (profile ? selectedReasoning(config, modelName) : "default");
    lines.push(`- ${state.projectId}/${task.id}｜模型：${modelName}${actualModel ? ` (${actualModel})` : ""}｜推理：${effort}｜状态：${taskState.status || "planned"}`);
    lines.push(`  > 内容：${compactText(task.description || task.prompt, 220)}`);
    if (taskState.error) lines.push(`  > 错误：${compactText(taskState.error, 220)}`);
  }
  const reviewModel = state.reviewModel || config.reviewModel;
  const reviewProfile = config.models[reviewModel];
  const reviewModelId = state.reviewModelId || reviewProfile?.model;
  lines.push("", `审查模型：${reviewModel}${reviewModelId ? ` (${reviewModelId})` : ""}｜推理：${state.reviewReasoning || selectedReasoning(config, reviewModel)}`);
  if (state.usage?.calls?.length) {
    const source = state.usage.calls.every((call) => call.reported) ? "API" : "API/估算";
    lines.push(`Token用量：${state.usage.totals.totalTokens}｜调用：${state.usage.calls.length}｜来源：${source}`);
  }
  if (state.finalReview) lines.push("", `审查：${state.finalReview}`);
  if (state.projectDocument) lines.push(`主文档：${state.projectDocument}`);
  if (state.executionBackend === "host-agents" && state.hostAgentTasks?.length) {
    lines.push("", `对话队列（仅限项目 ${state.projectId}，禁止跨项目复用）：`);
    for (const packet of state.hostAgentTasks) lines.push(`- ${packet.conversationTitle}`);
  }
  if (state.needsContinuation) lines.push("续批：需要调用 continue_goal 生成下一批任务。");
  if (state.goalComplete) lines.push("目标：goal_complete，已由 Sol 给出完成判定。");
  if (state.executionBackend === "host-agents") lines.push("并发说明：使用宿主子代理任务包；不是独立的顶层 Codex UI 对话。");
  return lines.join("\n");
}

function requestDocument(goal, context, projectId, name) {
  return `# ${projectId}: ${name}\n\n/gaol ${goal}\n\n## Context\n\n${context || "None provided."}`;
}

function planDocument(plan, state) {
  const lines = [`# ${state.projectId}: ${state.projectName}`, "", `/gaol ${state.goal}`, "", plan.summary, ""];
  for (const task of plan.tasks) {
    lines.push(`## ${task.id}: ${task.title}`, "", `- Owner: ${task.owner}`, `- Model: ${task.assignedModel || "assigned at execution"}`, `- Reasoning: ${task.assignedReasoning || "default"}`, `- Depends on: ${task.dependsOn.join(", ") || "none"}`, `- Deliverable: ${task.deliverable}`, "", task.description, "");
  }
  return lines.join("\n");
}

function promptDocument(goal, plan, task) {
  return [
    `# ${task.id}: ${task.title}`,
    "",
    `Owner: ${task.owner}`,
    `Assigned model: ${task.assignedModel || "pending"}`,
    `Reasoning effort: ${task.assignedReasoning || "default"}`,
    `Dependencies: ${task.dependsOn.join(", ") || "none"}`,
    "",
    "## Project goal",
    "",
    goal,
    "",
    "## Plan context",
    "",
    plan.summary,
    "",
    "## Detailed prompt",
    "",
    task.prompt,
    "",
    "## Acceptance criteria",
    "",
    ...(task.acceptanceCriteria.length ? task.acceptanceCriteria.map((item) => `- ${item}`) : ["- Satisfy the detailed prompt completely."]),
    "",
    "## Deliverable",
    "",
    task.deliverable,
    "",
    "Return only the deliverable and concise evidence. Do not change the project plan or claim work you did not verify."
  ].join("\n");
}

async function createPlan(args) {
  const workspace = workspaceRoot(args.workspace);
  const config = await loadConfig(workspace);
  const count = requestedCount(args, config);
  const projectId = await nextProjectId(workspace);
  const id = runId(args.goal);
  const projectRoot = projectArtifactRoot(workspace, config, projectId);
  const dir = path.join(projectRoot, `B01-${id}`);
  await fs.mkdir(path.join(dir, "tasks"), { recursive: true });
  await fs.mkdir(path.join(dir, "results"), { recursive: true });
  await fs.mkdir(path.join(dir, "reviews"), { recursive: true });
  const runOptions = { ...args, tokenMode: args.tokenMode || config.tokenMode, usageFile: path.join(dir, "usage.json"), phase: "planning" };
  let raw;
  try {
    raw = await callJson(config, config.solModel, planningMessages(args.goal, args.context, count, config, runOptions), runOptions);
  } catch (error) {
    const malformedJson = error instanceof SyntaxError || String(error.message).includes("did not contain JSON");
    if (runOptions.tokenMode !== "economy" || !malformedJson) throw error;
    const retryOptions = { ...runOptions, tokenMode: "balanced" };
    raw = await callJson(config, config.solModel, planningMessages(args.goal, args.context, count, config, retryOptions), retryOptions);
  }
  const plan = normalizePlan(raw, args.goal, count, config);
  let workerIndex = 0;
  for (const task of plan.tasks) {
    task.assignedModel = task.owner === "sol" ? config.solModel : selectWorker(task, workerIndex++, args, config);
    task.assignedReasoning = selectedReasoning(config, task.assignedModel, args);
  }
  const state = {
    runId: id,
    projectId,
    projectName: projectName(args),
    goal: args.goal,
    status: "planned",
    mode: config.mode,
    tokenMode: runOptions.tokenMode,
    artifactMode: config.artifactMode,
    executionBackend: selectedExecutionBackend(config, args),
    longRunning: Boolean(args.longRunning),
    batchNumber: 1,
    projectRoot,
    projectDocument: path.join(projectRoot, "PROJECT.md"),
    rootRun: dir,
    previousRun: null,
    goalComplete: false,
    needsContinuation: false,
    reviewModel: config.reviewModel,
    reviewReasoning: selectedReasoning(config, config.reviewModel, args),
    reviewModelId: config.models[config.reviewModel]?.model,
    createdAt: new Date().toISOString(),
    workspace,
    usage: await readUsage(dir),
    tasks: Object.fromEntries(plan.tasks.map((task) => [task.id, { status: "planned", owner: task.owner, model: task.assignedModel, modelId: config.models[task.assignedModel]?.model, reasoningEffort: task.assignedReasoning }]))
  };
  await writeText(path.join(dir, "request.md"), requestDocument(args.goal, args.context, state.projectId, state.projectName));
  await writeJson(path.join(dir, "plan.json"), plan);
  await writeText(path.join(dir, "plan.md"), planDocument(plan, state));
  for (const task of plan.tasks) await writeText(path.join(dir, "tasks", `${task.id}.prompt.md`), promptDocument(args.goal, plan, task));
  await writeProjectDocument(state, plan, dir, config);
  await writeJson(path.join(dir, "state.json"), state);
  return { workspace, config, plan, runDirectory: dir, state };
}

function selectWorker(task, index, args, config) {
  const requested = args.workerModel;
  if (requested) {
    if (!config.models[requested]) throw new Error(`Unknown worker model profile: ${requested}`);
    return requested;
  }
  if (task.preferredModel && config.workerModels.includes(task.preferredModel)) return task.preferredModel;
  return config.workerModels[index % config.workerModels.length];
}

async function prepareHostAgentRun(created, args = {}) {
  const { runDirectory: dir, config, plan } = created;
  const stateFile = path.join(dir, "state.json");
  const state = await readJson(stateFile);
  state.status = "awaiting_host_agents";
  state.executionBackend = "host-agents";
  state.hostAgentNotice = "Child-agent task packets are prepared. These are not top-level Codex UI conversations.";
  const packets = [];
  const approved = new Set(plan.tasks.filter((task) => state.tasks[task.id]?.status === "approved").map((task) => task.id));
  const orderedTasks = topologicalTaskOrder(plan.tasks).map((id) => plan.tasks.find((task) => task.id === id));
  let resultsReady = 0;
  let waitingDependencies = 0;
  for (const task of orderedTasks) {
    if (state.tasks[task.id]?.status === "approved") continue;
    const failedDependency = task.dependsOn.find((id) => ["failed", "rejected", "blocked"].includes(state.tasks[id]?.status));
    if (failedDependency) {
      state.tasks[task.id] = { ...state.tasks[task.id], status: "blocked", error: `Dependency ${failedDependency} did not pass Sol review` };
      continue;
    }
    const resultPath = path.join(dir, "results", `${task.id}.result.md`);
    if (await readOptionalText(resultPath)) {
      state.tasks[task.id] = { ...state.tasks[task.id], status: "result_ready", resultPath };
      resultsReady += 1;
      continue;
    }
    if (!task.dependsOn.every((id) => approved.has(id))) {
      state.tasks[task.id] = { ...state.tasks[task.id], status: "waiting_dependency", error: null };
      waitingDependencies += 1;
      continue;
    }
    const requestedModel = state.tasks[task.id]?.model || task.assignedModel;
    const conversationTitle = `${state.projectId} | ${requestedModel} | ${compactText(state.goal, 96)} | ${task.id}`;
    const packet = {
      projectId: state.projectId,
      batchNumber: state.batchNumber,
      taskId: task.id,
      title: task.title,
      conversationTitle,
      conversationKey: `${state.projectId}-B${String(state.batchNumber || 1).padStart(2, "0")}-${task.id}-${requestedModel}`,
      conversationScope: "single-project",
      conversationProjectId: state.projectId,
      reusePolicy: "same-project-only",
      dispatch: task.owner === "sol" ? "main-sol" : "subagent",
      requestedModel,
      requestedModelId: state.tasks[task.id]?.modelId || config.models[requestedModel]?.model,
      promptPath: path.join(dir, "tasks", `${task.id}.prompt.md`),
      resultPath,
      fileAccessMode: "isolated-results",
      sharedWorkspaceAccess: "read-only",
      exclusiveWritePath: resultPath
    };
    const originalPrompt = await readOptionalText(packet.promptPath);
    const dependencyResults = await dependencyContext(dir, task, config, args);
    const conversationHeader = [
      `# ${conversationTitle}`,
      "",
      "## File isolation",
      "",
      `- Conversation key: ${packet.conversationKey}`,
      `- This conversation is permanently bound to project: ${packet.conversationProjectId}`,
      "- Never send work from another project into this conversation; create a new conversation instead.",
      `- Read the shared project only; do not modify shared project files during parallel execution.`,
      `- Write only to: ${packet.exclusiveWritePath}`,
      "- Put proposed source changes or patches in the result file. Main Sol applies approved changes sequentially."
    ].join("\n");
    const dependencySection = dependencyResults ? `\n\n## Approved dependency results\n\n${dependencyResults}` : "";
    if (!originalPrompt.startsWith(`# ${conversationTitle}`)) await writeText(packet.promptPath, `${conversationHeader}\n\n${originalPrompt}${dependencySection}`);
    packets.push(packet);
    state.tasks[task.id] = {
      ...state.tasks[task.id],
      status: task.owner === "sol" ? "awaiting_main_sol" : "awaiting_subagent",
      dispatch: packet.dispatch,
      promptPath: packet.promptPath,
      resultPath: packet.resultPath
    };
  }
  state.hostAgentTasks = packets;
  if (!packets.length) {
    state.status = resultsReady ? "host_results_ready" : "host_dispatch_blocked";
    if (!resultsReady && waitingDependencies) state.hostAgentNotice = "No dependency-ready host tasks remain; inspect blocked or cyclic dependencies.";
  }
  await writeProjectDocument(state, plan, dir, config);
  await writeJson(stateFile, state);
  return {
    runDirectory: dir,
    projectId: state.projectId,
    status: state.status,
    executionBackend: "host-agents",
    requiresHostDispatch: packets.length > 0,
    hostAgentTasks: packets,
    nextTool: packets.length ? "After every resultPath in this dependency-ready wave exists, call review_run. If host agents are unavailable, call resume_run with executionBackend api-parallel." : (resultsReady ? "All available host results exist. Call review_run." : "Inspect blocked dependencies before resuming."),
    chatDisplay: chatCard(dir, state, plan, config, state.status)
  };
}

async function dependencyContext(dir, task, config, options) {
  const policy = tokenPolicy(config, options);
  const parts = [];
  for (const id of task.dependsOn) {
    const value = await fs.readFile(path.join(dir, "results", `${id}.result.md`), "utf8");
    parts.push(`## Dependency ${id}\n${clipped(value, policy.dependencyChars)}`);
  }
  return parts.join("\n\n");
}

async function executeTask(dir, goal, plan, task, model, config, options = {}) {
  const policy = tokenPolicy(config, options);
  const dependencyResults = await dependencyContext(dir, task, config, options);
  const prompt = [
    `Goal:\n${clipped(goal, policy.goalChars)}`,
    `Plan:\n${clipped(plan.summary, policy.planChars)}`,
    `Task ${task.id}: ${task.title}\n${clipped(task.prompt || task.description, policy.taskChars)}`,
    `Acceptance:\n${clipped(task.acceptanceCriteria.join("\n"), Math.floor(policy.taskChars / 2))}`,
    `Deliverable:\n${clipped(task.deliverable, 1200)}`,
    dependencyResults
  ].filter(Boolean).join("\n\n");
  const effort = selectedReasoning(config, model, options);
  const content = await callModel(config, model, [
    { role: "system", content: task.owner === "sol" ? "You are Sol. Complete this core task rigorously and concisely." : "Complete only this bounded task. Return the deliverable and concise evidence." },
    { role: "user", content: prompt }
  ], 0.2, { ...options, phase: "worker" });
  await writeText(path.join(dir, "results", `${task.id}.result.md`), `# ${task.id} Result\n\nModel: ${model}\nReasoning: ${effort}\n\n${content}`);
  return content;
}

function reviewMessages(goal, task, result, config, options) {
  const policy = tokenPolicy(config, options);
  const taskContract = {
    id: task.id,
    title: task.title,
    description: clipped(task.description, Math.floor(policy.taskChars / 2)),
    acceptanceCriteria: task.acceptanceCriteria,
    deliverable: task.deliverable
  };
  return [
    {
      role: "system",
      content: "You are Sol's reviewer. Check evidence and every criterion. progressDigest must state concrete completed work, artifacts, and remaining gaps for the next batch. JSON only: {decision:'approved'|'revise'|'rejected',summary,progressDigest,findings:[string],revisionPrompt}."
    },
    {
      role: "user",
      content: `Goal:\n${clipped(goal, policy.goalChars)}\n\nContract:\n${JSON.stringify(taskContract)}\n\nResult:\n${clipped(result, policy.reviewResultChars)}`
    }
  ];
}

async function reviewTask(dir, goal, task, result, config, options = {}) {
  const review = await callJson(config, config.reviewModel, reviewMessages(goal, task, result, config, options), { ...options, phase: "review" });
  const decision = ["approved", "revise", "rejected"].includes(review.decision) ? review.decision : "revise";
  const normalized = {
    decision,
    summary: String(review.summary || ""),
    progressDigest: String(review.progressDigest || review.summary || ""),
    findings: Array.isArray(review.findings) ? review.findings.map(String) : [],
    revisionPrompt: String(review.revisionPrompt || "")
  };
  await writeText(path.join(dir, "reviews", `${task.id}.review.md`), [
    `# ${task.id} Sol Review`,
    "",
    `Decision: ${normalized.decision}`,
    "",
    normalized.summary,
    "",
    "## Progress digest",
    "",
    normalized.progressDigest,
    "",
    "## Findings",
    "",
    ...(normalized.findings.length ? normalized.findings.map((item) => `- ${item}`) : ["- None."]),
    "",
    "## Revision prompt",
    "",
    normalized.revisionPrompt || "None."
  ].join("\n"));
  return normalized;
}

async function executeRun(created, args) {
  const { runDirectory: dir, config, plan } = created;
  const stateFile = path.join(dir, "state.json");
  const state = await readJson(stateFile);
  const runOptions = { ...args, executionBackend: "api-parallel", tokenMode: args.tokenMode || state.tokenMode || config.tokenMode, usageFile: path.join(dir, "usage.json") };
  state.status = "running";
  state.executionBackend = "api-parallel";
  state.tokenMode = runOptions.tokenMode;
  state.reviewModel = config.reviewModel;
  state.reviewReasoning = selectedReasoning(config, config.reviewModel, runOptions);
  state.reviewModelId = config.models[config.reviewModel]?.model;
  state.startedAt = new Date().toISOString();
  await writeJson(stateFile, state);
  let stateWrite = Promise.resolve();
  const persistState = () => {
    stateWrite = stateWrite.then(() => writeJson(stateFile, state));
    return stateWrite;
  };
  const complete = new Set(plan.tasks.filter((task) => state.tasks[task.id]?.status === "approved").map((task) => task.id));
  const failed = new Set();
  const pending = new Map(plan.tasks.filter((task) => !complete.has(task.id)).map((task) => [task.id, task]));
  let workerIndex = 0;
  while (pending.size) {
    const blocked = [...pending.values()].filter((task) => task.dependsOn.some((id) => failed.has(id)));
    for (const task of blocked) {
      state.tasks[task.id] = { ...state.tasks[task.id], status: "blocked", error: "A dependency failed or was rejected" };
      failed.add(task.id);
      pending.delete(task.id);
    }
    if (blocked.length) await persistState();
    if (!pending.size) break;
    const ready = [...pending.values()].filter((task) => task.dependsOn.every((id) => complete.has(id)));
    if (!ready.length) {
      for (const task of pending.values()) {
        state.tasks[task.id] = { ...state.tasks[task.id], status: "blocked", error: "Dependency cycle or missing dependency" };
        failed.add(task.id);
      }
      pending.clear();
      await persistState();
      break;
    }
    for (let offset = 0; offset < ready.length; offset += config.maxParallel) {
      const batch = ready.slice(offset, offset + config.maxParallel);
      await Promise.all(batch.map(async (task) => {
        const model = task.owner === "sol" ? config.solModel : (runOptions.workerModel || task.assignedModel || selectWorker(task, workerIndex++, runOptions, config));
        const reasoningEffort = selectedReasoning(config, model, runOptions);
        task.assignedModel = model;
        task.assignedReasoning = reasoningEffort;
        const attempts = (state.tasks[task.id]?.attempts || 0) + 1;
        state.tasks[task.id] = { ...state.tasks[task.id], status: "running", owner: task.owner, model, modelId: config.models[model]?.model, reasoningEffort, attempts, error: null };
        await persistState();
        try {
          let result = await executeTask(dir, state.goal, plan, task, model, config, runOptions);
          let review = await reviewTask(dir, state.goal, task, result, config, runOptions);
          if (review.decision === "revise") {
            const policy = tokenPolicy(config, runOptions);
            const revision = await callModel(config, model, [
              { role: "system", content: "Revise concisely. Address every Sol finding and preserve valid work." },
              { role: "user", content: `Result:\n${clipped(result, policy.reviewResultChars)}\n\nReview:\n${clipped(JSON.stringify(review), policy.finalReviewChars)}` }
            ], 0.2, { ...runOptions, phase: "worker" });
            result = revision;
            await writeText(path.join(dir, "results", `${task.id}.result.md`), `# ${task.id} Result (revised)\n\nModel: ${model}\nReasoning: ${reasoningEffort}\n\n${result}`);
            review = await reviewTask(dir, state.goal, task, result, config, runOptions);
          }
          state.tasks[task.id] = { ...state.tasks[task.id], status: review.decision, owner: task.owner, model, modelId: config.models[model]?.model, reasoningEffort, attempts, progressDigest: review.progressDigest };
          if (review.decision === "approved") complete.add(task.id);
          else failed.add(task.id);
        } catch (error) {
          state.tasks[task.id] = { ...state.tasks[task.id], status: "failed", owner: task.owner, model, modelId: config.models[model]?.model, reasoningEffort, attempts, error: compactText(error?.message || String(error), 500) };
          failed.add(task.id);
        }
        await persistState();
        pending.delete(task.id);
      }));
    }
  }
  await stateWrite;
  await writeJson(path.join(dir, "plan.json"), plan);
  if (failed.size) {
    state.status = "partial_failure";
    state.failedTasks = [...failed];
    state.resumable = true;
    state.needsContinuation = false;
    state.usage = await readUsage(dir);
    await writeProjectDocument(state, plan, dir, config);
    await writeJson(stateFile, state);
    return {
      runDirectory: dir,
      projectId: state.projectId,
      status: state.status,
      resumable: true,
      failedTasks: state.failedTasks,
      nextTool: "Call resume_run after correcting endpoint or task issues.",
      usage: state.usage,
      chatDisplay: chatCard(dir, state, plan, config, state.status)
    };
  }
  return finalizeReview(dir, config, runOptions);
}

async function finalizeReview(dir, config, options = {}) {
  const plan = await readJson(path.join(dir, "plan.json"));
  const stateFile = path.join(dir, "state.json");
  const state = await readJson(stateFile);
  const finalOptions = { ...options, tokenMode: options.tokenMode || state.tokenMode || config.tokenMode, usageFile: options.usageFile || path.join(dir, "usage.json"), phase: "final" };
  const policy = tokenPolicy(config, finalOptions);
  const packets = [];
  for (const task of plan.tasks) {
    const resultFile = path.join(dir, "results", `${task.id}.result.md`);
    let result;
    try { result = await fs.readFile(resultFile, "utf8"); }
    catch (error) { if (error.code === "ENOENT") continue; throw error; }
    const reviewFile = path.join(dir, "reviews", `${task.id}.review.md`);
    let review;
    try { review = await fs.readFile(reviewFile, "utf8"); }
    catch (error) {
      if (error.code !== "ENOENT") throw error;
      await reviewTask(dir, state.goal, task, result, config, finalOptions);
      review = await fs.readFile(reviewFile, "utf8");
    }
    packets.push(`${task.id} ${task.title} | owner=${task.owner} | status=${state.tasks[task.id]?.status || "unknown"}\n${clipped(review, policy.finalReviewChars)}`);
  }
  if (!packets.length) throw new Error(`No result documents found in ${path.join(dir, "results")}`);
  const planSummary = plan.tasks.map((task) => `${task.id}:${task.title}[${task.owner}]`).join("; ");
  const taskEntries = plan.tasks.map((task) => `${task.id} ${task.title}: ${state.tasks[task.id]?.status || "unknown"}`);
  const blocked = taskEntries.filter((entry) => !entry.endsWith(": approved"));
  const final = finalOptions.tokenMode === "economy"
    ? [
        `Decision: ${blocked.length ? "REVIEW_REQUIRED" : "APPROVED"}`,
        "",
        "## Task decisions",
        ...taskEntries.map((entry) => `- ${entry}`),
        "",
        "## Integration order",
        `- ${topologicalTaskOrder(plan.tasks).join(" -> ")}`,
        "",
        blocked.length ? "## Blockers\n" + blocked.map((entry) => `- ${entry}`).join("\n") : "## Remaining risks\n- See the individual Sol review documents for evidence and task-specific risks."
      ].join("\n")
    : await callModel(config, config.reviewModel, [
        { role: "system", content: "Give a concise release decision from Sol reviews only: approved items, blockers, integration order, risks. Never override a failed review." },
        { role: "user", content: `Goal:\n${clipped(state.goal, policy.goalChars)}\n\nPlan:\n${clipped(planSummary, policy.planChars)}\n\nReviews:\n${packets.join("\n\n")}` }
      ], 0.2, finalOptions);
  const finalFile = path.join(dir, "final-review.md");
  await writeText(finalFile, `# ${state.projectId}: Final Sol Review\n\n/gaol ${state.goal}\n\n${final}`);
  state.status = Object.values(state.tasks).some((task) => task.status !== "approved") ? "review_required" : "approved";
  state.needsContinuation = Boolean(state.longRunning && !state.goalComplete && ["approved", "review_required"].includes(state.status));
  state.completedAt = new Date().toISOString();
  state.finalReview = finalFile;
  state.usage = await readUsage(dir);
  await writeProjectDocument(state, plan, dir, config);
  await writeJson(stateFile, state);
  const chatDisplay = chatCard(dir, state, plan, config, state.status);
  await compactRun(dir, state, plan);
  return { runDirectory: dir, projectId: state.projectId, status: state.status, needsContinuation: state.needsContinuation, bundle: state.bundlePath || null, finalReview: finalFile, tasks: state.tasks, usage: state.usage, chatDisplay };
}

async function reviewRun(args) {
  const dir = path.resolve(args.runDirectory);
  let archived = null;
  try { archived = await readBundle(dir); } catch (error) { if (error.code !== "ENOENT") throw error; }
  if (archived) await expandBundleForReview(dir, archived);
  const state = await readJson(path.join(dir, "state.json"));
  const config = await loadConfig(state.workspace);
  const runOptions = { ...args, tokenMode: args.tokenMode || state.tokenMode || config.tokenMode, usageFile: path.join(dir, "usage.json") };
  state.tokenMode = runOptions.tokenMode;
  state.reviewModel = config.reviewModel;
  state.reviewReasoning = selectedReasoning(config, config.reviewModel, runOptions);
  state.reviewModelId = config.models[config.reviewModel]?.model;
  const plan = await readJson(path.join(dir, "plan.json"));
  const missingResults = [];
  for (const task of plan.tasks) {
    const resultFile = path.join(dir, "results", `${task.id}.result.md`);
    try {
      const result = await fs.readFile(resultFile, "utf8");
      if (state.tasks[task.id]?.status === "approved" && await readOptionalText(path.join(dir, "reviews", `${task.id}.review.md`))) continue;
      const review = await reviewTask(dir, state.goal, task, result, config, runOptions);
      state.tasks[task.id] = { ...state.tasks[task.id], status: review.decision, progressDigest: review.progressDigest };
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      state.tasks[task.id] = { ...state.tasks[task.id], status: "missing_result" };
      missingResults.push(task.id);
    }
  }
  await writeJson(path.join(dir, "state.json"), state);
  if (missingResults.length) {
    if (state.executionBackend === "host-agents") return prepareHostAgentRun({ workspace: state.workspace, config, plan, runDirectory: dir, state }, { ...args, executionBackend: "host-agents" });
    state.status = "missing_results";
    state.resumable = true;
    await writeJson(path.join(dir, "state.json"), state);
    return { runDirectory: dir, projectId: state.projectId, status: state.status, resumable: true, missingResults, nextTool: "Call resume_run after supplying or regenerating missing results.", chatDisplay: chatCard(dir, state, plan, config, state.status) };
  }
  return finalizeReview(dir, config, runOptions);
}

async function reviewSummaries(dir, plan, config, options) {
  const policy = tokenPolicy(config, options);
  let bundle = null;
  try { bundle = await readBundle(dir); } catch (error) { if (error.code !== "ENOENT") throw error; }
  const summaries = [];
  for (const task of plan.tasks) {
    const review = bundle?.reviews?.[task.id] || await readOptionalText(path.join(dir, "reviews", `${task.id}.review.md`));
    summaries.push(`${task.id} ${task.title}\n${clipped(review || "No review document", policy.finalReviewChars)}`);
  }
  return summaries.join("\n\n");
}

async function markContinued(dir, nextDir) {
  try {
    const file = path.join(dir, "state.json");
    const state = await readJson(file);
    state.needsContinuation = false;
    state.continuedBy = nextDir;
    await writeJson(file, state);
    return;
  } catch (error) { if (error.code !== "ENOENT") throw error; }
  const file = path.join(dir, "run-bundle.json");
  const bundle = await readJson(file);
  bundle.state.needsContinuation = false;
  bundle.state.continuedBy = nextDir;
  await writeJson(file, bundle);
}

function continuationMessages(state, plan, summaries, count, config, options) {
  const policy = tokenPolicy(config, options);
  const countRule = count ? `If incomplete, create exactly ${count} next tasks.` : `If incomplete, create 1 to ${config.maxTasksPerRun} next tasks.`;
  return [
    {
      role: "system",
      content: [
        "You are Sol maintaining a long-running goal.",
        "Decide goalComplete=true only when the final goal is fully satisfied and cite concrete completionEvidence.",
        countRule,
        "If incomplete, generate the smallest useful next batch; never return an empty task list.",
        "Keep core/high-risk work with owner 'sol'.",
        "JSON only: {goalComplete,completionEvidence:[string],progressSummary,tasks:[{id,title,owner,preferredModel,description,prompt,acceptanceCriteria,dependsOn,deliverable}]}."
      ].join("\n")
    },
    {
      role: "user",
      content: `Goal:\n${clipped(state.goal, policy.goalChars)}\n\nPrevious batch:\n${clipped(plan.summary, policy.planChars)}\n\nSol reviews:\n${clipped(summaries, policy.reviewResultChars)}`
    }
  ];
}

async function verifyGoalCompletion(state, raw, evidence, summaries, config, options) {
  const policy = tokenPolicy(config, options);
  try {
    const review = await callJson(config, config.reviewModel, [
      {
        role: "system",
        content: "Independently verify final-goal completion. Reject vague, circular, or unsupported evidence. JSON only: {approved:boolean,summary,findings:[string]}."
      },
      {
        role: "user",
        content: `Goal:\n${clipped(state.goal, policy.goalChars)}\n\nClaimed progress:\n${clipped(raw.progressSummary, policy.planChars)}\n\nCompletion evidence:\n${clipped(evidence.join("\n"), policy.finalReviewChars)}\n\nPrior Sol reviews:\n${clipped(summaries, policy.reviewResultChars)}`
      }
    ], { ...options, phase: "review" });
    return {
      approved: review.approved === true,
      summary: String(review.summary || ""),
      findings: Array.isArray(review.findings) ? review.findings.map(String) : []
    };
  } catch (error) {
    return { approved: false, summary: "Completion verification failed", findings: [compactText(error?.message || String(error), 500)] };
  }
}

async function existingContinuation(previousState) {
  if (!previousState.continuedBy) return null;
  const dir = path.resolve(previousState.continuedBy);
  const state = await readRunState(dir);
  const plan = await readRunPlan(dir);
  const config = await loadConfig(state.workspace);
  return {
    runDirectory: dir,
    projectId: state.projectId,
    status: state.status,
    goalComplete: Boolean(state.goalComplete),
    batchNumber: state.batchNumber,
    idempotent: true,
    chatDisplay: chatCard(dir, state, plan, config, state.status)
  };
}

async function continueGoal(args) {
  const previousDir = path.resolve(args.runDirectory);
  let previousState = await readRunState(previousDir);
  const existing = await existingContinuation(previousState);
  if (existing) return existing;
  const lockConfig = await loadConfig(previousState.workspace);
  const lockRoot = previousState.projectRoot || path.dirname(previousDir);
  const lockFile = path.join(lockRoot, `.continue-${createHash("sha256").update(previousDir).digest("hex").slice(0, 12)}.lock`);
  let lock;
  try {
    lock = await fs.open(lockFile, "wx");
    await lock.writeFile(JSON.stringify({ previousDir, createdAt: new Date().toISOString() }));
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    const lockStat = await fs.stat(lockFile);
    const staleAfterMs = lockConfig.requestTimeoutMs * (lockConfig.maxRetries + 1) + 60000;
    if (Date.now() - lockStat.mtimeMs > staleAfterMs) {
      await fs.rm(lockFile, { force: true });
      return continueGoal(args);
    }
    previousState = await readRunState(previousDir);
    const completed = await existingContinuation(previousState);
    if (completed) return completed;
    return { runDirectory: previousDir, projectId: previousState.projectId, status: "continuation_in_progress", idempotent: true, message: "Another continuation call is already creating the next batch." };
  }
  try {
    return await continueGoalUnlocked(args);
  } finally {
    await lock.close();
    await fs.rm(lockFile, { force: true });
  }
}

async function continueGoalUnlocked(args) {
  const previousDir = path.resolve(args.runDirectory);
  const previousState = await readRunState(previousDir);
  if (!previousState.longRunning) throw new Error("This run is not marked longRunning. Start /gaol with longRunning: true.");
  if (!["approved", "review_required"].includes(previousState.status)) throw new Error(`Run must be reviewed before continuation; current status is '${previousState.status}'`);
  const config = await loadConfig(previousState.workspace);
  const previousPlan = await readRunPlan(previousDir);
  const count = requestedCount(args, config);
  const id = runId(previousState.goal);
  const batchNumber = (previousState.batchNumber || 1) + 1;
  const projectRoot = previousState.projectRoot || projectArtifactRoot(previousState.workspace, config, previousState.projectId);
  const dir = path.join(projectRoot, `B${String(batchNumber).padStart(2, "0")}-${id}`);
  await fs.mkdir(path.join(dir, "tasks"), { recursive: true });
  await fs.mkdir(path.join(dir, "results"), { recursive: true });
  await fs.mkdir(path.join(dir, "reviews"), { recursive: true });
  const runOptions = { ...args, tokenMode: args.tokenMode || previousState.tokenMode || config.tokenMode, usageFile: path.join(dir, "usage.json"), phase: "planning" };
  const summaries = await reviewSummaries(previousDir, previousPlan, config, runOptions);
  let raw;
  try {
    raw = await callJson(config, config.solModel, continuationMessages(previousState, previousPlan, summaries, count, config, runOptions), runOptions);
  } catch (error) {
    const malformedJson = error instanceof SyntaxError || String(error.message).includes("did not contain JSON");
    if (runOptions.tokenMode !== "economy" || !malformedJson) throw error;
    const retryOptions = { ...runOptions, tokenMode: "balanced" };
    raw = await callJson(config, config.solModel, continuationMessages(previousState, previousPlan, summaries, count, config, retryOptions), retryOptions);
  }
  const evidence = Array.isArray(raw.completionEvidence) ? raw.completionEvidence.map(String).filter(Boolean) : [];
  if (raw.goalComplete && !evidence.length) raw.goalComplete = false;
  let completionVerification = null;
  if (raw.goalComplete) {
    completionVerification = await verifyGoalCompletion(previousState, raw, evidence, summaries, config, runOptions);
    if (!completionVerification.approved) raw.goalComplete = false;
  }
  let synthesizedFallback = false;
  if (!raw.goalComplete && (!Array.isArray(raw.tasks) || !raw.tasks.length)) {
    synthesizedFallback = true;
    const verificationContext = completionVerification?.findings?.length ? ` Address these completion-review findings: ${completionVerification.findings.join("; ")}` : "";
    raw.tasks = [{
      title: "Advance and verify the next milestone",
      owner: "sol",
      description: `Determine the next unmet milestone, execute it, and produce evidence.${verificationContext}`,
      prompt: `Identify the highest-priority unmet part of the final goal, complete it, and document verifiable evidence.${verificationContext}`,
      acceptanceCriteria: ["An unmet milestone is identified", "Concrete progress and evidence are produced"],
      dependsOn: [],
      deliverable: "Verified next-milestone result"
    }];
  }
  const baseState = {
    runId: id,
    projectId: previousState.projectId,
    projectName: previousState.projectName,
    goal: previousState.goal,
    mode: config.mode,
    tokenMode: runOptions.tokenMode,
    artifactMode: config.artifactMode,
    executionBackend: selectedExecutionBackend(config, args),
    longRunning: true,
    batchNumber,
    projectRoot,
    projectDocument: path.join(projectRoot, "PROJECT.md"),
    rootRun: previousState.rootRun || previousDir,
    previousRun: previousDir,
    reviewModel: config.reviewModel,
    reviewReasoning: selectedReasoning(config, config.reviewModel, runOptions),
    reviewModelId: config.models[config.reviewModel]?.model,
    createdAt: new Date().toISOString(),
    workspace: previousState.workspace,
    goalComplete: Boolean(raw.goalComplete),
    needsContinuation: false,
    completionVerification
  };
  if (raw.goalComplete) {
    const plan = { summary: String(raw.progressSummary || "Goal complete"), tasks: [] };
    const state = { ...baseState, status: "goal_complete", completionEvidence: evidence, tasks: {}, usage: await readUsage(dir) };
    const finalFile = path.join(dir, "final-review.md");
    state.finalReview = finalFile;
    await writeText(path.join(dir, "request.md"), requestDocument(state.goal, summaries, state.projectId, state.projectName));
    await writeJson(path.join(dir, "plan.json"), plan);
    await writeText(path.join(dir, "plan.md"), planDocument(plan, state));
    await writeText(finalFile, `# ${state.projectId}: Goal Complete\n\n/gaol ${state.goal}\n\n## Evidence\n\n${evidence.map((item) => `- ${item}`).join("\n")}\n\n## Independent verification\n\n${completionVerification.summary}`);
    await writeProjectDocument(state, plan, dir, config);
    await writeJson(path.join(dir, "state.json"), state);
    const chatDisplay = chatCard(dir, state, plan, config, state.status);
    await compactRun(dir, state, plan);
    await markContinued(previousDir, dir);
    return { runDirectory: dir, projectId: state.projectId, status: state.status, goalComplete: true, bundle: state.bundlePath || null, chatDisplay };
  }
  const plan = normalizePlan({ ...raw, summary: raw.progressSummary || "Next goal batch" }, previousState.goal, synthesizedFallback ? null : count, config);
  let workerIndex = 0;
  for (const task of plan.tasks) {
    task.assignedModel = task.owner === "sol" ? config.solModel : selectWorker(task, workerIndex++, args, config);
    task.assignedReasoning = selectedReasoning(config, task.assignedModel, runOptions);
  }
  const state = {
    ...baseState,
    status: "planned",
    tasks: Object.fromEntries(plan.tasks.map((task) => [task.id, { status: "planned", owner: task.owner, model: task.assignedModel, modelId: config.models[task.assignedModel]?.model, reasoningEffort: task.assignedReasoning }])),
    usage: await readUsage(dir)
  };
  await writeText(path.join(dir, "request.md"), requestDocument(state.goal, summaries, state.projectId, state.projectName));
  await writeJson(path.join(dir, "plan.json"), plan);
  await writeText(path.join(dir, "plan.md"), planDocument(plan, state));
  for (const task of plan.tasks) await writeText(path.join(dir, "tasks", `${task.id}.prompt.md`), promptDocument(state.goal, plan, task));
  await writeProjectDocument(state, plan, dir, config);
  await writeJson(path.join(dir, "state.json"), state);
  await markContinued(previousDir, dir);
  return { runDirectory: dir, projectId: state.projectId, status: "planned", goalComplete: false, batchNumber, taskCount: plan.tasks.length, chatDisplay: chatCard(dir, state, plan, config, "planned") };
}

async function statusRun(args) {
  const dir = path.resolve(args.runDirectory);
  const state = await readRunState(dir);
  const plan = await readRunPlan(dir);
  let bundle = null;
  try { bundle = await readBundle(dir); } catch (error) { if (error.code !== "ENOENT") throw error; }
  const missingResults = [];
  for (const task of plan.tasks) {
    if (bundle) {
      if (!bundle.results?.[task.id]) missingResults.push(task.id);
    } else {
      try { await fs.access(path.join(dir, "results", `${task.id}.result.md`)); }
      catch { missingResults.push(task.id); }
    }
  }
  state.usage = bundle?.usage || await readUsage(dir);
  const config = await loadConfig(state.workspace);
  return { runDirectory: dir, state, missingResults, chatDisplay: chatCard(dir, state, plan, config, state.status) };
}

async function resumeRun(args) {
  const dir = path.resolve(args.runDirectory);
  const state = await readRunState(dir);
  const allowed = ["partial_failure", "running", "awaiting_host_agents", "host_results_ready", "host_dispatch_blocked", "missing_results"];
  if (!allowed.includes(state.status)) throw new Error(`Run ${state.projectId || state.runId} is '${state.status}' and does not need resume_run`);
  const config = await loadConfig(state.workspace);
  const plan = await readRunPlan(dir);
  state.status = "planned";
  state.resumable = false;
  state.failedTasks = [];
  for (const task of plan.tasks) {
    if (state.tasks[task.id]?.status === "approved") continue;
    const resultFile = path.join(dir, "results", `${task.id}.result.md`);
    const reviewFile = path.join(dir, "reviews", `${task.id}.review.md`);
    const existingReview = await readOptionalText(reviewFile);
    if (existingReview.includes("Decision: approved") && await readOptionalText(resultFile)) {
      state.tasks[task.id] = { ...state.tasks[task.id], status: "approved", error: null };
      continue;
    }
    state.tasks[task.id] = { ...state.tasks[task.id], status: "planned", error: null };
  }
  await writeProjectDocument(state, plan, dir, config);
  await writeJson(path.join(dir, "state.json"), state);
  const created = { workspace: state.workspace, config, plan, runDirectory: dir, state };
  if (selectedExecutionBackend(config, args) === "host-agents") return prepareHostAgentRun(created, args);
  return executeRun(created, { ...args, executionBackend: "api-parallel" });
}

async function executeExistingRun(args) {
  const dir = path.resolve(args.runDirectory);
  const state = await readRunState(dir);
  if (state.status !== "planned") throw new Error(`Run ${state.projectId || state.runId} is '${state.status}', not 'planned'`);
  const config = await loadConfig(state.workspace);
  const plan = await readRunPlan(dir);
  if (config.mode === "documents") {
    return { runDirectory: dir, projectId: state.projectId, status: "planned", chatDisplay: chatCard(dir, state, plan, config, "planned") };
  }
  const created = { workspace: state.workspace, config, plan, runDirectory: dir, state };
  if (selectedExecutionBackend(config, args) === "host-agents") return prepareHostAgentRun(created, args);
  return executeRun(created, { ...args, executionBackend: "api-parallel" });
}

async function invokeTool(name, args) {
  if (name === "open_config_window") return openConfigWindow(args);
  if (name === "get_config") {
    const workspace = workspaceRoot(args.workspace);
    return { workspace, configPath: path.join(controlRoot(workspace), "config.json"), config: redactConfig(await loadConfig(workspace)) };
  }
  if (name === "configure") return configure(args);
  if (name === "plan_workflow") {
    const created = await createPlan(args);
    return { runDirectory: created.runDirectory, projectId: created.state.projectId, status: "planned", taskCount: created.plan.tasks.length, plan: path.join(created.runDirectory, "plan.md"), taskDirectory: path.join(created.runDirectory, "tasks"), chatDisplay: chatCard(created.runDirectory, created.state, created.plan, created.config, "planned") };
  }
  if (name === "run_workflow") {
    const created = await createPlan(args);
    if (created.config.mode === "documents") {
      return {
        runDirectory: created.runDirectory,
        status: "planned",
        taskCount: created.plan.tasks.length,
        plan: path.join(created.runDirectory, "plan.md"),
        taskDirectory: path.join(created.runDirectory, "tasks"),
        message: "Documents mode is enabled; place worker results under results/ and call review_run.",
        chatDisplay: chatCard(created.runDirectory, created.state, created.plan, created.config, "planned")
      };
    }
    if (selectedExecutionBackend(created.config, args) === "host-agents") return prepareHostAgentRun(created, args);
    return executeRun(created, { ...args, executionBackend: "api-parallel" });
  }
  if (name === "execute_run") return executeExistingRun(args);
  if (name === "resume_run") return resumeRun(args);
  if (name === "continue_goal") return continueGoal(args);
  if (name === "review_run") return reviewRun(args);
  if (name === "run_status") return statusRun(args);
  throw new Error(`Unknown tool: ${name}`);
}

function send(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`);
}

async function handle(message) {
  if (!message || message.jsonrpc !== "2.0") return;
  if (message.method === "initialize") {
    send({ jsonrpc: "2.0", id: message.id, result: { protocolVersion: message.params?.protocolVersion || "2024-11-05", capabilities: { tools: {} }, serverInfo: SERVER } });
    return;
  }
  if (message.method === "ping") {
    send({ jsonrpc: "2.0", id: message.id, result: {} });
    return;
  }
  if (message.method === "tools/list") {
    send({ jsonrpc: "2.0", id: message.id, result: { tools: TOOLS } });
    return;
  }
  if (message.method === "tools/call") {
    try {
      const result = await invokeTool(message.params?.name, message.params?.arguments || {});
      send({ jsonrpc: "2.0", id: message.id, result: { content: [{ type: "text", text: result.chatDisplay || JSON.stringify(result, null, 2) }], structuredContent: result } });
    } catch (error) {
      send({ jsonrpc: "2.0", id: message.id, result: { content: [{ type: "text", text: error?.message || String(error) }], isError: true } });
    }
    return;
  }
  if (message.id !== undefined && !message.method?.startsWith("notifications/")) {
    send({ jsonrpc: "2.0", id: message.id, error: { code: -32601, message: `Method not found: ${message.method}` } });
  }
}

let buffer = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buffer += chunk;
  let newline;
  while ((newline = buffer.indexOf("\n")) >= 0) {
    const line = buffer.slice(0, newline).trim();
    buffer = buffer.slice(newline + 1);
    if (!line) continue;
    try { void handle(JSON.parse(line)); }
    catch (error) { console.error(`Invalid MCP message: ${error.message}`); }
  }
});

process.stdin.on("end", () => {
  if (configUiServer) configUiServer.close(() => process.exit(0));
  else process.exit(0);
});
