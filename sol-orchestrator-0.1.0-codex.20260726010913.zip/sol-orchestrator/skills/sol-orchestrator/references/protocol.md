# Local Orchestration Protocol

## Model profiles

Each profile uses an OpenAI-compatible chat-completions endpoint:

```json
{
  "name": "sol-5.6",
  "model": "your-deployed-model-id",
  "baseUrl": "http://127.0.0.1:8000/v1",
  "apiKeyEnv": "SOL_API_KEY",
  "reasoningEffort": "high",
  "reasoningField": "reasoning_effort",
  "maxTokensField": "max_tokens",
  "temperatureEnabled": false
}
```

`apiKeyEnv` is optional. A base URL may end in `/v1` or `/v1/chat/completions`.
Reasoning values are `default`, `none`, `minimal`, `low`, `medium`, `high`, or `xhigh`. `default` omits the request field. Set `reasoningField` to an empty string when the endpoint does not support reasoning controls.
Use `maxTokensField: "max_completion_tokens"` when required by the endpoint, or an empty string to disable output caps.
`temperatureEnabled` defaults to false because many reasoning endpoints reject temperature. Enable it only for compatible models.

## Configuration window

Call `open_config_window` when the user wants visual model selection. It starts an ephemeral Chinese configuration page on `127.0.0.1`, binds it to the requested workspace, and returns a clickable URL. Each random session expires after 30 minutes. The page can add, remove, or rename profiles; choose Sol, reviewer, and worker roles; select reasoning effort; set automatic or fixed task counts; and edit execution, token, archive, retry, and endpoint options.

The page stores only API-key environment variable names. It never accepts or persists API-key values. A visual save replaces the complete profile list so deleted profiles do not remain as hidden configuration.

## Token modes

- `economy` (default): compact context and capped outputs; final status is generated locally from mandatory Sol reviews, avoiding a redundant synthesis call.
- `balanced`: larger task and review budgets plus a Sol final synthesis.
- `quality`: largest budgets for high-risk work.

Every API call is recorded in `usage.json` while a batch is active and moved into `run-bundle.json` during compact archiving. When the endpoint returns usage metadata it is used directly; otherwise the plugin records a conservative local estimate. Local task and result documents remain complete even when inter-model context is clipped.

## Continuous goals

Pass `longRunning: true` for a long-lived `/gaol`. An approved batch returns `needsContinuation: true`, not goal completion. Call `continue_goal` with the latest run directory. Sol receives only the goal and compact review summaries; it either creates the next batch under the same project ID or returns `goal_complete` with completion evidence. Empty continuation plans are replaced with a Sol-owned progress task so task exhaustion cannot block the project.

`continue_goal` is idempotent. Repeating it for the same batch returns the existing successor; a project lock prevents concurrent calls from creating two B02 branches. A completion claim is sent to `reviewModel` in a separate call and becomes `goal_complete` only when that independent verification approves it.

## Execution backends

- `api-parallel`: execute tasks with parallel OpenAI-compatible API calls inside one Codex conversation.
- `host-agents`: return task packets for host child agents. `main-sol` stays in the lead context; each `subagent` packet may use one child-agent conversation. These are not top-level Codex UI threads.
- `auto`: resolve to `api-parallel` in the MCP server. The skill selects `host-agents` only after detecting host collaboration tools.

Host-agent packets contain `conversationTitle`, stable `conversationKey`, `promptPath`, and a unique `exclusiveWritePath`. Use the title format `P0001 | model | final goal | T02` as the first line of the child-agent prompt and never create two agents for the same key. The same titles are listed under `对话队列` in the chat card. Agents may read shared project files but must write only their own result path. Proposed code changes remain patches in the result document; main Sol applies approved changes sequentially.

Every packet also carries `conversationScope: single-project`, an immutable `conversationProjectId`, and `reusePolicy: same-project-only`. One project may use N child conversations, but one child conversation must never receive packets from more than one project. When the project ID changes, create a new child conversation even if the model or task type is unchanged.

Packets are returned in dependency-ready waves. Independent tasks can create N child conversations, while a task with unresolved dependencies stays `waiting_dependency`. After the current wave writes its unique result files, call `review_run`; approved results are not reviewed again, and the next dependency-ready wave is returned. This prevents dependent conversations from reading or changing files before their inputs are stable. If host agents are unavailable, call `resume_run` with `executionBackend: api-parallel` and disclose the fallback.

## Recovery

Retryable HTTP 408/409/425/429/5xx, timeouts, and transport failures use exponential backoff. A failed task is checkpointed without discarding successful peers. Dependency failures become `blocked`; the run returns `partial_failure`. Call `resume_run` to retry only failed, blocked, interrupted, or missing tasks. Approved tasks and valid approved review files are reused.

## Project storage

User-facing files live inside the original workspace:

```text
sol-orchestrator-projects/
  P0001/
    PROJECT.md
    B01-<run-id>/
      run-bundle.json
      final-review.md
```

`PROJECT.md` contains the final goal, latest batch, task/model summary, and the prompt required to continue. In default `compact` mode, completed batch files are merged into `run-bundle.json`; only the bundle and final review remain. Set `artifactMode: expanded` only when every intermediate handoff file must remain separate.

## Modes

- `auto`: choose the configured worker for each delegated task and use the configured default task count.
- `manual`: use the requested worker and task count. The count must be between 1 and the configured maximum.
- `documents`: generate task documents without calling workers. External workers write matching files under `results/`, then `review_run` performs the Sol review.

For visible execution, call `plan_workflow`, display its `chatDisplay`, then call `execute_run`. The one-call `run_workflow` remains available for automation.

## Chat review card

Every plan, status, and final result returns a compact Markdown card:

```text
/gaol <final goal>
### 项目 P0001 · <project name>
- P0001/T01｜模型：sol-5.6 (5.6sol)｜推理：high｜状态：planned
  > 内容：<task summary>
```

## Run documents

During an active batch, the batch directory temporarily contains:

```text
request.md
plan.json
plan.md
tasks/<task-id>.prompt.md
results/<task-id>.result.md
reviews/<task-id>.review.md
final-review.md
state.json
usage.json
```

Workers receive only their prompt document. Sol receives the original request, plan, worker result, and acceptance criteria during review.

## Security

Use loopback or trusted HTTPS endpoints. Put keys in environment variables. Do not store secrets in plugin configuration or task documents.
